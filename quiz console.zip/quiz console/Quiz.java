import java.util.ArrayList;
import java.util.List;

public class Quiz {
    private String question;
    private List<String> options = new ArrayList<>();
    private int correctAnswer; // 1..4

    public Quiz(String question, List<String> options, int correctAnswer) {
        this.question = question;
        this.options = options;
        this.correctAnswer = correctAnswer;
    }

    public void displayQuestion() {
        System.out.println("\nQ) " + question);
        for (int i = 0; i < options.size(); i++) {
            System.out.println("  " + (i + 1) + ". " + options.get(i));
        }
    }

    public boolean checkAnswer(int choice) {
        return choice == correctAnswer;
    }
}
