import java.sql.*;
import java.util.*;

// Handles adding and testing questions
public class QuestionService {

    // Add a question
    public static void addQuestion(String qtype, String q, 
            String a, String b, String c, String d, String correct) {
        try (Connection con = DB.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
              "INSERT INTO questions(qtype, question, option_a, option_b, option_c, option_d, correct) VALUES(?,?,?,?,?,?,?)");
            ps.setString(1, qtype);   // set question type
            ps.setString(2, q);       // question text
            ps.setString(3, a);       // option A
            ps.setString(4, b);       // option B
            ps.setString(5, c);       // option C
            ps.setString(6, d);       // option D
            ps.setString(7, correct); // correct answer
            ps.executeUpdate();       // run query
            System.out.println("✅ Question added!");
        } catch (Exception e) { e.printStackTrace(); }
    }

    // Student takes test
    public static void takeTest() {
        try (Connection con = DB.getConnection()) {
            Statement st = con.createStatement();
            // Pick 5 random questions
            ResultSet rs = st.executeQuery("SELECT * FROM questions ORDER BY RAND() LIMIT 5");

            Scanner sc = new Scanner(System.in);
            int score = 0;

            while (rs.next()) {
                String type = rs.getString("qtype");
                System.out.println("\nQ: " + rs.getString("question"));

                if (type.equals("MCQ")) {
                    // Show 4 options
                    System.out.println("A) " + rs.getString("option_a"));
                    System.out.println("B) " + rs.getString("option_b"));
                    System.out.println("C) " + rs.getString("option_c"));
                    System.out.println("D) " + rs.getString("option_d"));
                    System.out.print("Your Answer (A/B/C/D): ");
                    String ans = sc.next().toUpperCase();
                    if (ans.equals(rs.getString("correct"))) score++;
                } 
                else if (type.equals("FILLUP")) {
                    System.out.print("Fill the blank: ");
                    sc.nextLine(); // clear buffer
                    String ans = sc.nextLine();
                    if (ans.equalsIgnoreCase(rs.getString("correct"))) score++;
                } 
                else if (type.equals("STATEMENT")) {
                    System.out.print("True/False: ");
                    sc.nextLine(); // clear buffer
                    String ans = sc.nextLine();
                    if (ans.equalsIgnoreCase(rs.getString("correct"))) score++;
                }
            }
            System.out.println("\n🏆 Your Score = " + score + "/5");
        } catch (Exception e) { e.printStackTrace(); }
    }
}
