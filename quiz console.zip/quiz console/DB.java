import java.sql.*;

// DB helper class to connect MySQL
public class DB {
    // JDBC URL: database name = quiz_simple
    private static final String URL = "jdbc:mysql://localhost:3306/quiz_simple";
    private static final String USER = "root";       // your MySQL username
    private static final String PASS = "password";   // your MySQL password

    // Method to get a new database connection
    public static Connection getConnection() throws Exception {
        // DriverManager gives a new connection
        return DriverManager.getConnection(URL, USER, PASS);
    }
}
