// Simple Question class (POJO)
public class Question {
    int id;              // question ID
    String question;     // the question text
    String optionA, optionB, optionC, optionD;  // only for MCQ
    String correct;      // correct answer
    String qtype;        // MCQ / FILLUP / STATEMENT
}
