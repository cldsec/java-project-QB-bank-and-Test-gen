import java.util.*;

public class MainApp {
    static Scanner sc = new Scanner(System.in);
    static List<User> users = new ArrayList<>();
    static List<Quiz> quizzes = new ArrayList<>();

    public static void main(String[] args) {
        // seed one teacher & one student so you can test quickly
        users.add(new User("teacher1", "1234", "TEACHER"));
        users.add(new User("student1", "1234", "STUDENT"));

        while (true) {
            System.out.println("\n=== QUIZ CONSOLE APP ===");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose: ");

            String pick = sc.nextLine().trim();
            switch (pick) {
                case "1": register(); break;
                case "2": loginFlow(); break;
                case "3": System.out.println("Bye!"); return;
                default: System.out.println("Invalid option."); 
            }
        }
    }

    // ---------- Registration ----------
    static void register() {
        System.out.println("\n--- Register ---");
        String username;
        while (true) {
            System.out.print("Choose username: ");
            username = sc.nextLine().trim();
            if (username.isEmpty()) { System.out.println("Username cannot be empty."); continue; }
            if (findUser(username) != null) { System.out.println("Username already taken. Try another."); continue; }
            break;
        }

        String password;
        while (true) {
            System.out.print("Choose password: ");
            password = sc.nextLine().trim();
            if (password.isEmpty()) { System.out.println("Password cannot be empty."); continue; }
            break;
        }

        String role;
        while (true) {
            System.out.print("Role (TEACHER/STUDENT): ");
            role = sc.nextLine().trim().toUpperCase();
            if (!role.equals("TEACHER") && !role.equals("STUDENT")) {
                System.out.println("Enter TEACHER or STUDENT only.");
                continue;
            }
            break;
        }

        users.add(new User(username, password, role));
        System.out.println("✅ Registered! You can login now.");
    }

    // ---------- Login ----------
    static void loginFlow() {
        System.out.println("\n--- Login ---");
        System.out.print("Username: ");
        String uname = sc.nextLine().trim();
        System.out.print("Password: ");
        String pass = sc.nextLine().trim();

        User u = authenticate(uname, pass);
        if (u == null) {
            System.out.println("❌ Invalid credentials.");
            return;
        }

        System.out.println("✅ Welcome " + u.getUsername() + " (" + u.getRole() + ")");
        if ("TEACHER".equals(u.getRole())) teacherMenu();
        else studentMenu();
    }

    static User authenticate(String uname, String pass) {
        for (User u : users) {
            if (u.getUsername().equals(uname) && u.getPassword().equals(pass)) return u;
        }
        return null;
    }

    static User findUser(String uname) {
        for (User u : users) if (u.getUsername().equalsIgnoreCase(uname)) return u;
        return null;
    }

    // ---------- Teacher ----------
    static void teacherMenu() {
        while (true) {
            System.out.println("\n--- Teacher Menu ---");
            System.out.println("1. Add Question (MCQ)");
            System.out.println("2. List Questions");
            System.out.println("3. Logout");
            System.out.print("Choose: ");
            String c = sc.nextLine().trim();

            switch (c) {
                case "1": addQuizQuestion(); break;
                case "2": listQuestions(); break;
                case "3": return;
                default: System.out.println("Invalid option.");
            }
        }
    }

    static void addQuizQuestion() {
        System.out.print("Enter question: ");
        String q = sc.nextLine().trim();
        List<String> opts = new ArrayList<>();
        for (int i = 1; i <= 4; i++) {
            System.out.print("Option " + i + ": ");
            opts.add(sc.nextLine().trim());
        }
        int ansNum;
        while (true) {
            System.out.print("Correct option number (1-4): ");
            try {
                ansNum = Integer.parseInt(sc.nextLine().trim());
                if (ansNum < 1 || ansNum > 4) { System.out.println("Enter 1..4 only."); continue; }
                break;
            } catch (NumberFormatException e) { System.out.println("Enter a number 1..4."); }
        }
        quizzes.add(new Quiz(q, opts, ansNum));
        System.out.println("✅ Question added. Total questions: " + quizzes.size());
    }

    static void listQuestions() {
        if (quizzes.isEmpty()) { System.out.println("No questions yet."); return; }
        int idx = 1;
        for (Quiz quiz : quizzes) {
            System.out.print("#" + idx++);
            quiz.displayQuestion();
        }
    }

    // ---------- Student ----------
    static void studentMenu() {
        while (true) {
            System.out.println("\n--- Student Menu ---");
            System.out.println("1. Attempt Quiz (all questions)");
            System.out.println("2. Logout");
            System.out.print("Choose: ");
            String c = sc.nextLine().trim();

            switch (c) {
                case "1": attemptQuiz(); break;
                case "2": return;
                default: System.out.println("Invalid option.");
            }
        }
    }

    static void attemptQuiz() {
        if (quizzes.isEmpty()) {
            System.out.println("⚠ No questions uploaded yet.");
            return;
        }
        int score = 0;
        int total = quizzes.size();

        for (Quiz quiz : quizzes) {
            quiz.displayQuestion();
            int choice;
            while (true) {
                System.out.print("Your answer (1-4): ");
                try {
                    choice = Integer.parseInt(sc.nextLine().trim());
                    if (choice < 1 || choice > 4) { System.out.println("Enter 1..4 only."); continue; }
                    break;
                } catch (NumberFormatException e) { System.out.println("Enter a number 1..4."); }
            }
            if (quiz.checkAnswer(choice)) {
                System.out.println("✅ Correct");
                score++;
            } else {
                System.out.println("❌ Wrong");
            }
        }

        System.out.println("\n🎯 Result: " + score + " / " + total);
    }
}
